<?php
namespace conexion;
use PDO;
use PDOException;

class Conexion {
   
    private $stm;
    private $pdo;

    public function __construct() {
        try {
            $this->pdo = new PDO('mysql:host=localhost;dbname=ejercicio', 'root', '');
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo 'Error de conexión: ' . $e->getMessage();
            exit();
        }
    }

    public function beginTransaction() { 
        $this->pdo->beginTransaction(); 
    }
    
    public function commit() { 
        $this->pdo->commit(); 
    }
    public function rollback() { 
        $this->pdo->rollBack(); 
    }

    public function prepare($sql) {
        try { $this->stm = $this->pdo->prepare($sql); return $this->stm; 
        } 
        catch (PDOException $ex) { error_log($ex->getMessage()); return null;
     } }

    public function consultar($sql) {
        try {
            $this->stm = $this->pdo->prepare($sql);
            $this->stm->execute();
            return $this->stm->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            error_log($ex->getMessage());
            return null;
        }
    }

    public function lastInsertId() { 
        return $this->pdo->lastInsertId(); }

    public function cerrar() {
        $this->stm = null;
        $this->pdo = null;
    }
}
?>