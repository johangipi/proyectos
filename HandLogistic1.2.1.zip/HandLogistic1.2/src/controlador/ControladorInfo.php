<?php
namespace controlador;
require __DIR__ . '/../../vendor/autoload.php';
session_start();
use conexion\Conexion;

class ControladorInfo {

    public function guardarInfo() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_SPECIAL_CHARS);
            $email = filter_input(INPUT_POST, 'correo', FILTER_SANITIZE_EMAIL);
            $mensaje = filter_input(INPUT_POST, 'mensaje', FILTER_SANITIZE_SPECIAL_CHARS);

            if ($nombre && $email && $mensaje) {
                $conexion = new Conexion();
                $sql = "INSERT INTO informacion (nombre, correo, mensaje) VALUES (:nombre, :correo, :mensaje)";
                $stmt = $conexion->prepare($sql);
                $stmt->bindParam(':nombre', $nombre);
                $stmt->bindParam(':correo', $email);
                $stmt->bindParam(':mensaje', $mensaje);

                $result = $stmt->execute();

                if ($result) {
                    echo 'Información guardada correctamente.';
                    header('Location: ../vista/index.php'); // Redirige a una página de agradecimiento
                    exit();
                } else {
                    echo 'Error al guardar la información.';
                }
                $conexion->cerrar();
            } else {
                echo 'Datos inválidos.';
            }
        }
    }
}

// Crear instancia del controlador y manejar las acciones
$controlador = new ControladorInfo();
$controlador->guardarInfo();

?>
