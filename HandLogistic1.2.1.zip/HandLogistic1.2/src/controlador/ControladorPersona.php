<?php 
namespace controlador; 
require __DIR__ . '/../../vendor/autoload.php';
use conexion\conexion;
use modelo\Persona;
use PDO;

class ControladorPersona {
    
    public function registro(){
        session_start(); // Asegúrate de iniciar la sesión
        if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
            $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_SPECIAL_CHARS); 
            $apellido = filter_input(INPUT_POST, 'apellido', FILTER_SANITIZE_SPECIAL_CHARS); 
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL); 
            $contrasena = filter_input(INPUT_POST, 'contrasena', FILTER_SANITIZE_SPECIAL_CHARS); 
            $role_id = filter_input(INPUT_POST, 'role_id', FILTER_VALIDATE_INT); // Suponiendo que también envías el role_id
            
            // Verificar si el usuario tiene permiso
            $idUsuario = $_SESSION['idUsuario']; // ID del usuario que está intentando registrar
            if ($this->tienePermiso($idUsuario)) {
                if ($nombre && $apellido && $email && $contrasena && $role_id) { 
                    $persona = new Persona(); 
                    $persona->setNombre($nombre); 
                    $persona->setApellido($apellido); 
                    $persona->setEmail($email); 
                    $persona->setContrasena($contrasena); 
                    $persona->setRoleId($role_id);
                    $conexion = new conexion(); 
                    $sql = "INSERT INTO personas (nombre, apellido, email, contrasena, role_id) VALUES (:nombre, :apellido, :email, MD5(:contrasena), :role_id)"; 
                    $stmt = $conexion->prepare($sql); 
                    $stmt->execute([ 
                        ':nombre' => $persona->getNombre(), 
                        ':apellido' => $persona->getApellido(), 
                        ':email' => $persona->getEmail(), 
                        ':contrasena' => $persona->getContrasena(),
                        ':role_id' => $persona->getRoleId()
                    ]); 
                    $conexion->cerrar(); 
                    header('Location: ../vista/index.php'); 
                    exit(); 
                } else {
                    echo 'Datos invalidos.';
                }
            } else {
                echo 'No tienes permisos para registrar usuarios.';
            }
        }
    }

    private function tienePermiso($idUsuario) {
        $conexion = new conexion();
        $sql = "SELECT role_id FROM personas WHERE id = :usuarioId";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':usuarioId' => $idUsuario]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        $conexion->cerrar();
        
        // Asumiendo que el rol de administrador es 1
        return $usuario && $usuario['role_id'] == 1;
    }

    // ... las demás funciones permanecen sin cambios ...
    
    public function actualizarRegistro() { 
        session_start(); 
        $persona = new Persona(); 
        $conexion = new conexion(); 
        if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'actualizarRegistro') { 
            $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_SPECIAL_CHARS); 
            $apellido = filter_input(INPUT_POST, 'apellido', FILTER_SANITIZE_SPECIAL_CHARS); 
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL); 
            $contrasena = filter_input(INPUT_POST, 'contrasena', FILTER_SANITIZE_SPECIAL_CHARS); 
            if ($nombre && $apellido && $email && $contrasena) { 
                $persona->setNombre($nombre); 
                $persona->setApellido($apellido); 
                $persona->setEmail($email); 
                $persona->setContrasena($contrasena); 
                
                $sql = $persona->actualizar(); 
                $stmt = $conexion->prepare($sql); 
                $result = $stmt->execute(); 
                
                if ($result) { 
                    echo "Registro actualizado correctamente.<br>"; 
                    header('Location: ../vista/home.php'); 
                    exit(); 
                } else { 
                    $errorInfo = $stmt->errorInfo(); 
                    die("Error al actualizar el registro: " . htmlspecialchars($errorInfo[2]) . "<br>"); 
                } 
                $conexion->cerrar(); 
            } else { 
                echo 'Todos los campos son obligatorios.'; 
            } 
        } else { 
            echo 'Método de solicitud no válido o acción no especificada.'; 
        } 
    }

    public function eliminarUsuario() { 
        session_start();
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'delete') { 
            $idUsuario = $_SESSION['idUsuario']; // ID del usuario que está intentando eliminar 
            if ($this->tienePermiso($idUsuario)) { 
                $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT); 
                if ($id !== false) { $conexion = new conexion(); 
                    $sql = "DELETE FROM personas WHERE id = ?"; 
                    $stmt = $conexion->prepare($sql); 
                    $stmt->execute([$id]); 
                    $conexion->cerrar(); 
                    header('Location: ../vista/usuarios.php'); 
                    exit(); 
                } else { 
                    echo 'ID inválido.'; 
                } 
            } else { 
                echo 'No tienes permisos para eliminar usuarios.'; 
            } 
        }
    }
}

$controlador = new ControladorPersona(); 
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD']) { 
    $action = $_POST['action'] ?? ''; 
    
    switch ($action) { 
        case 'registro': 
            $controlador->registro(); 
            break; 
        case 'actualizarRegistro': 
            $controlador->actualizarRegistro(); 
            break; 
        case 'delete': 
            $controlador->eliminarUsuario(); 
            break;
        default:
            echo 'acción no válida';
    }
}
?>
