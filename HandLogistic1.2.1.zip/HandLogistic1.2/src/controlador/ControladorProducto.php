<?php 

namespace controlador;

use PDO; 
require __DIR__ . '/../../vendor/autoload.php';
session_start();
use conexion\Conexion;
use modelo\Producto;
use FPDF;
class ControladorProducto {

    public function registrarProducto() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $idUsuario = $_SESSION['idUsuario'];
            $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_SPECIAL_CHARS);
            $item = filter_input(INPUT_POST, 'item', FILTER_SANITIZE_SPECIAL_CHARS);
            $categoria = filter_input(INPUT_POST, 'categoria', FILTER_SANITIZE_SPECIAL_CHARS);
            $ubicacion = filter_input(INPUT_POST, 'ubicacion', FILTER_SANITIZE_SPECIAL_CHARS);
            $cantidad = filter_input(INPUT_POST, 'cantidad', FILTER_VALIDATE_INT);
            $precio = filter_input(INPUT_POST, 'precio', FILTER_VALIDATE_FLOAT);
    
            if ($idUsuario && $nombre && $item && $categoria && $ubicacion && $cantidad !== false && $precio !== false) {
                $conexion = new Conexion();
    
                // Verificar si ya existe un producto con el mismo ítem
                $sql = "SELECT id, cantidad FROM producto WHERE item = :item";
                $stmt = $conexion->prepare($sql);
                $stmt->bindParam(':item', $item);
                $stmt->execute();
                $productoExistente = $stmt->fetch(PDO::FETCH_ASSOC);
    
                if ($productoExistente) {
                    // Si el producto ya existe, actualizar la cantidad
                    $id = $productoExistente['id'];
                    $nuevaCantidad = $productoExistente['cantidad'] + $cantidad;
                    $sql = "UPDATE producto SET cantidad = :cantidad, nombre = :nombre, categoria = :categoria, ubicacion = :ubicacion, precio = :precio WHERE id = :id";
                    $stmt = $conexion->prepare($sql);
                    $stmt->bindParam(':cantidad', $nuevaCantidad);
                    $stmt->bindParam(':nombre', $nombre);
                    $stmt->bindParam(':categoria', $categoria);
                    $stmt->bindParam(':ubicacion', $ubicacion);
                    $stmt->bindParam(':precio', $precio);
                    $stmt->bindParam(':id', $id);
                } else {
                    // Si el producto no existe, insertar uno nuevo
                    $sql = "INSERT INTO producto (nombre, item, categoria, ubicacion, cantidad, precio, idUsuario) VALUES (:nombre, :item, :categoria, :ubicacion, :cantidad, :precio, :idUsuario)";
                    $stmt = $conexion->prepare($sql);
                    $stmt->bindParam(':nombre', $nombre);
                    $stmt->bindParam(':item', $item);
                    $stmt->bindParam(':categoria', $categoria);
                    $stmt->bindParam(':ubicacion', $ubicacion);
                    $stmt->bindParam(':cantidad', $cantidad);
                    $stmt->bindParam(':precio', $precio);
                    $stmt->bindParam(':idUsuario', $idUsuario);
                }
    
                $result = $stmt->execute();
    
                if ($result) {
                    echo 'Producto registrado correctamente. ID de Usuario: ' . $idUsuario;
                    header('Location: ../vista/interfaz.php');
                    exit();
                } else {
                    echo 'Error al registrar el producto.';
                }
                $conexion->cerrar();
            } else {
                echo 'Datos inválidos.';
            }
        }
    }  

    public function obtenerProducto() {
        if (isset($_GET['item'])) {
            $item = filter_input(INPUT_GET, 'item', FILTER_SANITIZE_SPECIAL_CHARS);
    
            if ($item) {
                $conexion = new Conexion();
                $sql = "SELECT nombre, precio FROM producto WHERE item = :item";
                $stmt = $conexion->prepare($sql);
                $stmt->bindParam(':item', $item);
                $stmt->execute();
                $producto = $stmt->fetch(PDO::FETCH_ASSOC);
    
                $conexion->cerrar();
    
                if ($producto) {
                    echo json_encode($producto);
                    return;
                }
            }
        }
    
        echo json_encode(null);
    }
    

    public function eliminarProducto() { 
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'eliminar') { 
            $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT); 
            
            if ($id !== false) { 
                $conexion = new Conexion(); 
                $sql = "DELETE FROM producto WHERE id = ?"; 
                $stmt = $conexion->prepare($sql); 
                $stmt->execute([$id]); 
                $conexion->cerrar(); 
                header('Location: ../vista/inventario.php'); 
                exit(); 
            } else { 
                echo 'ID inválido.'; 
            } 
        } 
    }

    public function filtrarPorCategoria() { 
        if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
            $categoria = filter_input(INPUT_POST, 'categoria', FILTER_SANITIZE_SPECIAL_CHARS); 
            if ($categoria) { 
                $productos = Producto::filtrarPorCategoria($categoria); 
                // Aquí puedes pasar los productos a la vista 
                include '../vista/producto.php'; 
            } else { 
                echo 'Categoría inválida.'; 
            } 
        } 
    }

    public function facturar() { 
        if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
            if (!isset($_SESSION['productos']) || empty($_SESSION['productos'])) { 
                echo "No hay productos para facturar."; 
                return; 
            } 
            $conexion = new Conexion();
            $totalFactura = 0; 
            foreach ($_SESSION['productos'] as $producto) { 
                $totalFactura += $producto['total']; 
            } 
            // Insertar la factura 
            $sql = "INSERT INTO facturas (total) VALUES (:total)"; 
            $stmt = $conexion->prepare($sql); 
            $stmt->bindParam(':total', $totalFactura); 
            $stmt->execute(); 
            $facturaId = $conexion->lastInsertId(); 
            // Insertar los detalles de la factura y actualizar la cantidad de productos 
            foreach ($_SESSION['productos'] as $producto) { 
                $sql = "INSERT INTO factura_detalle (factura_id, producto_id, cantidad, precio_unitario, total) VALUES (:factura_id, :producto_id, :cantidad, :precio_unitario, :total)"; 
                $stmt = $conexion->prepare($sql); 
                $stmt->bindParam(':factura_id', $facturaId); 
                $stmt->bindParam(':producto_id', $producto['id']); 
                $stmt->bindParam(':cantidad', $producto['cantidad']); 
                $stmt->bindParam(':precio_unitario', $producto['precio']); 
                $stmt->bindParam(':total', $producto['total']); 
                $stmt->execute(); 
                // Actualizar la cantidad del producto en la tabla de productos 
                $sql = "UPDATE producto SET cantidad = cantidad - :cantidad WHERE id = :id"; 
                $stmt = $conexion->prepare($sql); 
                $stmt->bindParam(':cantidad', $producto['cantidad']); 
                $stmt->bindParam(':id', $producto['id']); 
                $stmt->execute(); 
            } 

            $pdf = new FPDF();
            $pdf->AddPage();
            $pdf->SetFont('Arial','B',16);
            $pdf->Cell(0,10,'Factura No: ' . $facturaId, 0, 1, 'C');
            $pdf->Ln(10);

            $pdf->SetFont('Arial','B',12);
            $pdf->Cell(40,10,'Producto', 1);
            $pdf->Cell(40,10,'Cantidad', 1);
            $pdf->Cell(40,10,'Precio Unitario', 1);
            $pdf->Cell(40,10,'Total', 1);
            $pdf->Ln(10);

            $pdf->SetFont('Arial','',12);
            foreach ($_SESSION['productos'] as $producto) {
                $pdf->Cell(40, 10, $producto['nombre'], 1); 
                $pdf->Cell(40, 10, $producto['cantidad'], 1); 
                $pdf->Cell(40, 10, '$' . number_format($producto['precio'], 2), 1); 
                $pdf->Cell(40, 10, '$' . number_format($producto['total'], 2), 1); 
                $pdf->Ln(10);
            }

            $pdf->Ln(10); 
            $pdf->SetFont('Arial', 'B', 12); 
            $pdf->Cell(120, 10, 'Total Factura', 1); 
            $pdf->Cell(40, 10, '$' . number_format($totalFactura, 2), 1); 
            $pdf->Output('F', 'factura_' . $facturaId . '.pdf');

            // Limpiar los productos de la sesión 
            unset($_SESSION['productos']); 
            $conexion->cerrar(); 
            header('Location: ../vista/facturacion.php'); 
            exit(); 
        } 
    } 

    public function disminuir() { 
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'disminuir') { 
            $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT); 
            $cantidad = filter_input(INPUT_POST, 'cantidad', FILTER_VALIDATE_INT);
            
            if ($id !== false && $cantidad !== false && $cantidad > 0) { 
                $conexion = new Conexion(); 
                // Iniciar una transacción
                $conexion->beginTransaction(); 
    
                // Disminuir la cantidad
                $sql = "UPDATE producto SET cantidad = cantidad - ? WHERE id = ?"; 
                $stmt = $conexion->prepare($sql); 
                $stmt->execute([$cantidad, $id]);
    
                // Verificar si la cantidad ahora es cero o menor
                $sql = "SELECT cantidad FROM producto WHERE id = ?"; 
                $stmt = $conexion->prepare($sql); 
                $stmt->execute([$id]); 
                $nuevaCantidad = $stmt->fetchColumn(); 
    
                if ($nuevaCantidad <= 0) { 
                    // Eliminar el producto si la cantidad es cero o menor
                    $sql = "DELETE FROM producto WHERE id = ?"; 
                    $stmt = $conexion->prepare($sql); 
                    $stmt->execute([$id]); 
                }
    
                // Confirmar la transacción
                $conexion->commit(); 
                
                $conexion->cerrar(); 
                header('Location: ../vista/inventario.php'); 
                exit(); 
            } else { 
                echo 'ID o cantidad inválida.'; 
            } 
        } 
    }
}      

$controlador = new ControladorProducto(); 
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') { 
    $action = $_POST['action'] ?? ''; 
    
    switch ($action) { 
        case 'registrarProducto': 
            $controlador->registrarProducto(); 
            break; 
        case 'eliminar': 
            $controlador->eliminarProducto(); 
            break; 
        case 'disminuir': 
            $controlador->disminuir(); 
            break;
        case 'filtrarPorCategoria': 
            $controlador->filtrarPorCategoria(); 
            break;
        case 'facturar':
            $controlador->facturar();
        default:
            echo 'Acción no válida';
    }
}

?>

