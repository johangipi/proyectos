<?php 
require_once __DIR__ . '/../../vendor/autoload.php';
use conexion\Conexion;
session_start();

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario</title>
    <?php include 'MenuUsuario.php'?>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .low-quantity {
            background-color: #ffcccc; /* Rojo claro */
        }

        .medium-quantity {
            background-color: #ffebcc; /* Naranja claro */
        }

        .high-quantity {
            background-color: #cce5ff; /* Azul claro */
        }

        .action-form {
            display: inline;
        }

        .action-button {
            padding: 5px 10px;
            margin: 2px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .action-button.decrease {
            background-color: #4CAF50; /* Verde */
            color: white;
        }

        .action-button.delete {
            background-color: #f44336; /* Rojo */
            color: white;
        }

        .action-button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="content">
    <h1>Inventario de Productos</h1>

    <form method="POST" action="../controlador/ControladorProducto.php"> 
        <label for="categoria">Filtrar por categoría:</label> 
        <select name="categoria" id="categoria"> 
            <option value="">Seleccione una categoría</option> 
            <?php 
            // Obtener las categorías únicas de la base de datos 
            $conexion = new Conexion(); 
            $sql = "SELECT DISTINCT categoria FROM producto"; 
            $result = $conexion->consultar($sql); 
            // Mostrar las categorías en el select 
            foreach ($result as $row) { 
                echo "<option value='" . htmlspecialchars($row['categoria']) . "'>" . htmlspecialchars($row['categoria']) . "</option>"; 
            } 
            $conexion->cerrar(); 
            ?> 
        </select> 
        <button type="submit" name="action" value="filtrarPorCategoria">Filtrar</button> 
    </form>
            
    <table class="tabla_productos">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Ítem</th>
                <th>Categoría</th>
                <th>Ubicación</th>
                <th>Cantidad</th>
                <th>precio Un</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Obtener los productos de la base de datos
            $conexion = new Conexion();
            $sql = "SELECT * FROM producto";
            $result = $conexion->consultar($sql);

            // Mostrar los productos en la tabla con estilos condicionales
            foreach ($result as $row) {
                $clase = '';
                if ($row['cantidad'] < 30) {
                    $clase = 'low-quantity';
                } elseif ($row['cantidad'] >= 31 && $row['cantidad'] <= 49) {
                    $clase = 'medium-quantity';
                } else {
                    $clase = 'high-quantity';
                }
                echo "<tr class='{$clase}'>";
                echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
                echo "<td>" . htmlspecialchars($row['item']) . "</td>";
                echo "<td>" . htmlspecialchars($row['categoria']) . "</td>";
                echo "<td>" . htmlspecialchars($row['ubicacion']) . "</td>";
                echo "<td>" . htmlspecialchars($row['cantidad']) . "</td>";
                echo "<td>". htmlspecialchars($row["precio"]) . "</td>";
                echo "<td>";
                echo "<form class='action-form' method='POST' action='../controlador/ControladorProducto.php' style='display:inline;'>";
                echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
                echo "<input type='hidden' name='action' value='disminuir'>";
                echo "<input type='number' name='cantidad' min='1' placeholder='Cantidad' required>";
                echo "<button type='submit' class='action-button decrease'>Disminuir</button>";
                echo "</form>";
                echo "<form class='action-form' method='POST' action='../controlador/ControladorProducto.php' style='display:inline;'>";
                echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
                echo "<input type='hidden' name='action' value='eliminar'>";
                echo "<button type='submit' class='action-button delete'>Eliminar</button>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
            }

            $conexion->cerrar();
            ?>
        </tbody>
    </table>
    </div>
</body>
</html>
