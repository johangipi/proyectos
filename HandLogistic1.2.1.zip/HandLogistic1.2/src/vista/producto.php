<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Productos Filtrados</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-form {
            display: inline;
        }

        .action-button {
            padding: 5px 10px;
            margin: 2px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .action-button.decrease {
            background-color: #4CAF50; /* Verde */
            color: white;
        }

        .action-button.delete {
            background-color: #f44336; /* Rojo */
            color: white;
        }

        .action-button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
<?php include 'MenuUsuario.php'; ?>
    <div class="content">
    <h1>Productos en la categoría: <?php echo htmlspecialchars($_POST['categoria']); ?></h1>
    <table class="tabla_productos">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Ítem</th>
                <th>Categoría</th>
                <th>Ubicación</th>
                <th>Cantidad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!empty($productos)) {
                foreach ($productos as $producto) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($producto['nombre']) . "</td>";
                    echo "<td>" . htmlspecialchars($producto['item']) . "</td>";
                    echo "<td>" . htmlspecialchars($producto['categoria']) . "</td>";
                    echo "<td>" . htmlspecialchars($producto['ubicacion']) . "</td>";
                    echo "<td>" . htmlspecialchars($producto['cantidad']) . "</td>";
                    echo "<td>";
                    echo "<form class='action-form' method='POST' action='../controlador/ControladorProducto.php' style='display:inline;'>";
                    echo "<input type='hidden' name='id' value='" . htmlspecialchars($producto['id']) . "'>";
                    echo "<input type='hidden' name='action' value='disminuir'>";
                    echo "<button type='submit' class='action-button decrease'>Disminuir</button>";
                    echo "</form>";
                    echo " ";
                    echo "<form class='action-form' method='POST' action='../controlador/ControladorProducto.php' style='display:inline;'>";
                    echo "<input type='hidden' name='id' value='" . htmlspecialchars($producto['id']) . "'>";
                    echo "<input type='hidden' name='action' value='eliminar'>";
                    echo "<button type='submit' class='action-button delete'>Eliminar</button>";
                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No se encontraron productos en esta categoría.</td></tr>";
            }
            ?>
        </tbody>
    </table>
    </div>
</body>
</html>

