<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Facturación</title>
    <!--<link rel="stylesheet" href="../vista/css/estilos.css">  Asegúrate de actualizar la ruta -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-button {
            padding: 5px 10px;
            margin: 2px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            background-color: #4CAF50; /* Verde */
            color: white;
        }

        .action-button:hover {
            opacity: 0.8;
        }

        .delete-button {
            background-color: #f44336; /* Rojo */
        }

        .decrease-button {
            background-color: #ff9800; /* Naranja */
        }

        .facturar-button {
            background-color: #2196F3; /* Azul */
        }
    </style>
</head>
<body>
    <?php 
    require_once __DIR__ . '/../../vendor/autoload.php';
    use conexion\Conexion;
    session_start();
    include 'MenuUsuario.php'; 
    ?>

    <div class="content">
        <h1>Facturación</h1>

        <form method="POST" action="">
            <label for="item">Ítem:</label><br>
            <input type="text" id="item" name="item" required><br><br>

            <label for="cantidad">Cantidad:</label><br>
            <input type="number" id="cantidad" name="cantidad" min="1" required><br><br>

            <button type="submit" class="action-button" name="agregarProducto">Agregar Producto</button>
        </form>

        <h2>Detalle de la Factura</h2>
        <table>
            <thead>
                <tr>
                    <th>Ítem</th>
                    <th>Nombre</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Total</th>
                    <th>Acciones</th> <!-- Nueva columna para las acciones -->
                </tr>
            </thead>
            <tbody>
                <?php

                if (!isset($_SESSION['productos'])) {
                    $_SESSION['productos'] = [];
                }

                // Manejando las acciones de eliminar y disminuir
                if (isset($_POST['eliminarProducto'])) {
                    $indice = filter_input(INPUT_POST, 'indice', FILTER_VALIDATE_INT);
                    if ($indice !== false && isset($_SESSION['productos'][$indice])) {
                        array_splice($_SESSION['productos'], $indice, 1);
                    }
                } elseif (isset($_POST['disminuirProducto'])) {
                    $indice = filter_input(INPUT_POST, 'indice', FILTER_VALIDATE_INT);
                    $cantidad = filter_input(INPUT_POST, 'cantidad', FILTER_VALIDATE_INT);
                    if ($indice !== false && $cantidad !== false && isset($_SESSION['productos'][$indice])) {
                        $_SESSION['productos'][$indice]['cantidad'] -= $cantidad;
                        if ($_SESSION['productos'][$indice]['cantidad'] <= 0) {
                            array_splice($_SESSION['productos'], $indice, 1);
                        } else {
                            $_SESSION['productos'][$indice]['total'] = $_SESSION['productos'][$indice]['precio'] * $_SESSION['productos'][$indice]['cantidad'];
                        }
                    }
                } elseif (isset($_POST['agregarProducto'])) {
                    $item = filter_input(INPUT_POST, 'item', FILTER_SANITIZE_SPECIAL_CHARS);
                    $cantidad = filter_input(INPUT_POST, 'cantidad', FILTER_VALIDATE_INT);

                    if ($item && $cantidad) {
                        $conexion = new Conexion();
                        $sql = "SELECT id, nombre, precio FROM producto WHERE item = :item";
                        $stmt = $conexion->prepare($sql);
                        $stmt->bindParam(':item', $item);
                        $stmt->execute();
                        $producto = $stmt->fetch(PDO::FETCH_ASSOC);

                        if ($producto) {
                            $producto['item'] = $item;
                            $producto['cantidad'] = $cantidad;
                            $producto['total'] = $producto['precio'] * $cantidad;
                            $_SESSION['productos'][] = $producto;
                        } else {
                            echo "<tr><td colspan='6'>Producto no encontrado.</td></tr>";
                        }
                        $conexion->cerrar();
                    }
                }

                $totalFactura = 0;
                foreach ($_SESSION['productos'] as $indice => $producto) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($producto['item']) . "</td>";
                    echo "<td>" . htmlspecialchars($producto['nombre']) . "</td>";
                    echo "<td>" . htmlspecialchars($producto['cantidad']) . "</td>";
                    echo "<td>$" . number_format($producto['precio'], 2) . "</td>";
                    echo "<td>$" . number_format($producto['total'], 2) . "</td>";
                    echo "<td>";
                    echo "<form method='POST' action='' style='display:inline;'>";
                    echo "<input type='hidden' name='indice' value='{$indice}'>";
                    echo "<input type='number' name='cantidad' min='1' placeholder='Cantidad' required>";
                    echo "<button type='submit' class='action-button decrease-button' name='disminuirProducto'>Disminuir</button>";
                    echo "</form>";
                    echo "<form method='POST' action='' style='display:inline;'>";
                    echo "<input type='hidden' name='indice' value='{$indice}'>";
                    echo "<button type='submit' class='action-button delete-button' name='eliminarProducto'>Eliminar</button>";
                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                    $totalFactura += $producto['total'];
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" style="text-align: right;">Total:</td>
                    <td><?php echo "$" . number_format($totalFactura, 2); ?></td>
                </tr>
            </tfoot>
        </table>

        <form method="POST" action="../controlador/ControladorProducto.php">
            <button type="submit" class="action-button facturar-button" name="action" value="facturar">Facturar</button>
        </form>
    </div>
</body>
</html>
