<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Menu de Usuario</title>
    <link rel="stylesheet" href="../vista/css/Menu.css" type="text/css"/>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
        <img src="https://cdn-icons-png.flaticon.com/512/145/145809.png">
        </div>
        <div class="menu-toggle" id="menu-toggle">&#9776;</div>
    </nav>
    <ul class="menu" id="menu">
        <li><a href="/src/vista/home.php">Home</a></li>
        <li><a href="/src/vista/registro.php">Registrar Usuario</a></li>
        <li><a href="/src/vista/interfaz.php">Registrar producto</a></li>
        <li><a href="/src/vista/inventario.php">Mi Inventario</a></li>
        <li><a href="/src/vista/usuarios.php">Usuarios</a></li>
        <li><a href="/src/vista/facturacion.php">Facturacion</a></li>
    </ul>

    <script>
        document.getElementById('menu-toggle').addEventListener('click', function() {
            document.getElementById('menu').classList.toggle('active');
            document.getElementById('content').classList.toggle('menu-active');
        });
    </script>
</body>
</html>
