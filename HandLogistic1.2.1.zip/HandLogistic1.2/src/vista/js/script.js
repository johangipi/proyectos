document.getElementById('agregarProducto').addEventListener('click', function() {
    const item = document.getElementById('item').value;
    const cantidad = parseInt(document.getElementById('cantidad').value);

    if (item && cantidad > 0) {
        // Realizar una solicitud AJAX para obtener los detalles del producto
        fetch(`../controlador/ControladorProducto.php?action=obtenerProducto&item=${item}`)
            .then(response => response.json())
            .then(producto => {
                if (producto) {
                    // Agregar el producto a la tabla de detalles
                    const totalProducto = producto.precio * cantidad;
                    const fila = `
                        <tr>
                            <td>${item}</td>
                            <td>${producto.nombre}</td>
                            <td>${cantidad}</td>
                            <td>$${producto.precio.toFixed(2)}</td>
                            <td>$${totalProducto.toFixed(2)}</td>
                        </tr>
                    `;
                    document.querySelector('#detalleFactura tbody').insertAdjacentHTML('beforeend', fila);

                    // Actualizar el total de la factura
                    const totalFactura = parseFloat(document.getElementById('totalFactura').innerText.replace('$', '')) + totalProducto;
                    document.getElementById('totalFactura').innerText = `$${totalFactura.toFixed(2)}`;
                } else {
                    alert('Producto no encontrado.');
                }
            })
            .catch(error => {
                console.error('Error al obtener el producto:', error);
            });
    }
});
